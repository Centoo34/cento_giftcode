
ESX = exports['es_extended']:getSharedObject()  -- alebo použite iný spôsob na získanie ESX

RegisterServerEvent("giftcode:redeem")
AddEventHandler("giftcode:redeem", function(code)
    local xPlayer = ESX.GetPlayerFromId(source)
    local reward = Config.GiftCodes[code]

    if reward then
        -- Pridajte item do inventára
        exports.ox_inventory:AddItem(source, reward.item, reward.count)

        -- Poslanie notifikácie hráčovi
        TriggerClientEvent('ox_lib:notify', source, {type = 'success', description = Config.Notify.Success})
    else
        -- Poslanie notifikácie o nesprávnom kóde
        TriggerClientEvent('ox_lib:notify', source, {type = 'error', description = Config.Notify.Failure})
    end
end)
