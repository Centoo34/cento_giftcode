
Config = {}

Config.GiftCodes = {
    ["GIFT2023"] = {item = "bread", count = 5}
}

Config.Notify = {
    Success = "Správny kód! Odmena bola pridaná do tvojho inventára."-- sucfes notify,
    Failure = "Nesprávny kód! Skús to znova." -- afd failure message when code is not right
}
