
RegisterCommand("giftcode", function()
    local input = lib.inputDialog("Gift Code", {
        {type = "input", label = "Zadaj tvoj gift kód", placeholder = "Napíš kód sem"}
    })

    if input and input[1] then
        TriggerServerEvent("giftcode:redeem", input[1])
    end
end)
